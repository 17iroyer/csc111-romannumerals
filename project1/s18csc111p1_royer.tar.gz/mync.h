/*
* Project 1: Roman and Arabic number Converters
* Programmer: Ian Royer
* Course: S18 CSC111
* Professor: Dr. Lee
*/

int r2a();                 //Roman to Arabic function

char *a2r();               //Arabic to Roman function
